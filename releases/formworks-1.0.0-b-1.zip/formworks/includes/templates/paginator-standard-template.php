<ul style="float: left; margin: 0px; padding: 1px 0px;">
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">Prev</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">1</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">2</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px; background: rgb(159, 159, 159) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px;" class="current" href="#0">3</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">4</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><span style="text-decoration: none; display: inline-block; padding: 6px;">...</span>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">20</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">21</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">22</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">23</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">24</a>
	<li style="display: inline-block; margin: 0px 6px 0px 0px;"><a style="text-decoration: none; display: inline-block; padding: 6px;" href="#0">Next</a>
</ul>