
	<h4><?php esc_html_e('Report Summary', 'formworks'); ?></h4>
	<p>{{{this}}}</p>
