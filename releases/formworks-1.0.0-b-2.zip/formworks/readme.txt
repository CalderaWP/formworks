=== Formworks ===
Contributors: Desertsnowman, Shelob9
Donate link: https://CalderaWP.com
Tags:
Requires at least: 3.9
Tested up to: 4.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Form Analitic and Submission Management Suite

== Description ==

Form Analitic and Submission Management Suite

Formworks is a free plugin by [CalderaWP](https://CalderaWP.com).

== Installation ==

Install the plugin through the WordPress Plugins Installer or upload `plugin-name.php` to the plugins directory of your content directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Does It Got To Eleven? =

Of course it does.

== Screenshots ==

1. Screenshot 1 description
2. Screenshot 2 description

== Changelog ==

= 0.1.0 =
Initial Version

== Upgrade Notice ==
Nothing to report
