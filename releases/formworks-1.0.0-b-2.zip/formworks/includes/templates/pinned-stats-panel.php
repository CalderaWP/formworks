<?php
/**
 * Panel template for Stats
 *
 * @package   Formworks
 * @author    David Cramer
 * @license   GPL-2.0+
 * @link
 * @copyright 2015 David Cramer
 */
global $wpdb;


	/**
	 * Include the access-panel
	 */
	include FRMWKS_PATH . 'includes/templates/pinned-main-stats-template.php';
