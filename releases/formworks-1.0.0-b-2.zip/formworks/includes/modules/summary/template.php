
	<h4><?php _e('Report Summary', 'formworks'); ?></h4>
	<p>{{{this}}}</p>
